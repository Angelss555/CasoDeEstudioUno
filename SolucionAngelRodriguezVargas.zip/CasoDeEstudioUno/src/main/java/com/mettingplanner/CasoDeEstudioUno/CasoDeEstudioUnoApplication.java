package com.mettingplanner.CasoDeEstudioUno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasoDeEstudioUnoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasoDeEstudioUnoApplication.class, args);
	}

}
