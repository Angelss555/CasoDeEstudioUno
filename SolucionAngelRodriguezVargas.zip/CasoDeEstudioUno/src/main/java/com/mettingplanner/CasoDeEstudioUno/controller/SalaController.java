package com.mettingplanner.CasoDeEstudioUno.controller;

import com.mettingplanner.CasoDeEstudioUno.service.SalaService;
import com.mettingplanner.CasoDeEstudioUno.model.Sala;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Controller
@RequestMapping("/salas")
public class SalaController {
    
    //Cargamos los atributos
    private final SalaService salaService;

    public SalaController(SalaService salaService) { this.salaService = salaService; }

    //Con el get mapping hacemos el método de listar salas
    @GetMapping
    public String listarSalas(Model model) {
        model.addAttribute("salas", salaService.getAll());
        return "salas/lista";
    }

    //Creamos el método para mostrar el formulario
    @GetMapping("/agregar")
    public String mostrarFormulario(Model model) {
        model.addAttribute("sala", new Sala(null, "", 0));
        return "salas/form";
    }

    //Creamos el método para agregar sala
    @PostMapping("/agregar")
    public String agregarSala(@ModelAttribute Sala sala, RedirectAttributes ra) {
        if(sala.getNombre().isEmpty() || sala.getCapacidad() <= 0){
            ra.addFlashAttribute("error", "Datos inválidos");
            return "redirect:/salas/agregar";
        }
        salaService.agregarSala(sala.getNombre(), sala.getCapacidad());
        ra.addFlashAttribute("success", "Sala agregada");
        return "redirect:/salas";
    }

    //Finalmente creamos el método para eliminar 
    @GetMapping("/eliminar/{id}")
    public String eliminarSala(@PathVariable Long id, RedirectAttributes ra) {
        salaService.eliminarSala(id);
        ra.addFlashAttribute("success", "Sala eliminada");
        return "redirect:/salas";
    }
    
}