package com.mettingplanner.CasoDeEstudioUno.service;

import com.mettingplanner.CasoDeEstudioUno.model.Reunion;
import com.mettingplanner.CasoDeEstudioUno.model.Sala;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Service
public class ReunionService {
    //Cargamos una lista y sus atributos
    private List<Reunion> reuniones = new ArrayList<>();
    private Long contadorId = 1L; 
    
    public List<Reunion> getAll() {
        return reuniones;
    }
    
    //Creamos el método para agregar una nueva reunion
    public void agregarReunion(String titulo, String fecha, String hora, Long salaId) {
        reuniones.add(new Reunion(contadorId++, titulo, java.time.LocalDate.parse(fecha), hora, salaId));
    }
    
    //Nuevamente creamos un filtro para reunión
    public Optional<Reunion> getById(Long id){
        return reuniones.stream().filter(r -> r.getId().equals(id)).findFirst();
    }
    
    //Creamos el método para eliminar una reunión
    public void eliminarReunion(Long id) {
        reuniones.removeIf(r -> r.getId().equals(id));      
    }
    
    //Para finalizar creamos el método para editar la reunión
    public void editarReunion(Long id, String titulo, String fecha, String hora, Long salaId) {
        getById(id).ifPresent(r -> {
            r.setTitulo(titulo);
            r.setFecha(java.time.LocalDate.parse(fecha));
            r.setHora(hora);
            r.setSalaId(salaId);
        });
    }
    
    }