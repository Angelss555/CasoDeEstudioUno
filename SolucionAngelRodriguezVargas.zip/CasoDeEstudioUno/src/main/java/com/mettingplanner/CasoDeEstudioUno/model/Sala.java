package com.mettingplanner.CasoDeEstudioUno.model;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */
public class Sala {
    
    //Creamos nuestros atributos
    private Long id;
    private String nombre;
    private int capacidad;
    
    //Constructor de la Sala
    public Sala(Long id, String nombre, int capacidad) {
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
    }
    
    //Creamos los Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getCapacidad() { return capacidad; }
    public void setCapacidad(int capacidad) { this.capacidad = capacidad; }
        
}