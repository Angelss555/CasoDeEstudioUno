package com.mettingplanner.CasoDeEstudioUno.controller;

import com.mettingplanner.CasoDeEstudioUno.service.ReunionService;
import com.mettingplanner.CasoDeEstudioUno.service.SalaService;
import com.mettingplanner.CasoDeEstudioUno.model.Reunion;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Controller
@RequestMapping("/reuniones")
public class ReunionController {
    //Cargamos los atributos
    
    private final ReunionService reunionService;
    private final SalaService salaService;
    
    public ReunionController(ReunionService reunionService, SalaService salaService) {
        this.reunionService = reunionService;
        this.salaService = salaService;
    }

    //Creamos el método para listar salas
    @GetMapping
    public String listarReuniones(Model model) {
        model.addAttribute("reuniones", reunionService.getAll());
        model.addAttribute("salas", salaService.getAll()); 
        return "reuniones/lista";
    }

    //Seguidamente se define el método para mostrar el formulario
    @GetMapping("/agregar")
    public String mostrarFormulario(Model model) {
        model.addAttribute("reunion", new Reunion(null, "", null, "", null));
        model.addAttribute("salas", salaService.getAll()); 
        return "reuniones/form";
    }

    //Creamos el método para agregar una nueva reunión
    @PostMapping("/agregar")
    public String agregarReunion(@ModelAttribute Reunion reunion,
                                 RedirectAttributes ra) {

        if (reunion.getTitulo().isEmpty() ||
            reunion.getFecha() == null ||
            reunion.getHora().isEmpty() ||
            reunion.getSalaId() == null) {

            ra.addFlashAttribute("error", "Todos los campos son obligatorios");
            return "redirect:/reuniones/agregar";
        }

        reunionService.agregarReunion(
                reunion.getTitulo(),
                reunion.getFecha().toString(),
                reunion.getHora(),
                reunion.getSalaId()
        );

        ra.addFlashAttribute("success", "Reunión registrada correctamente");
        return "redirect:/reuniones";
    }

    //Y finalmente creamos el método para eliminar una reunión
    @GetMapping("/eliminar/{id}")
    public String eliminarReunion(@PathVariable Long id,
                                  RedirectAttributes ra) {
        reunionService.eliminarReunion(id);
        ra.addFlashAttribute("success", "Reunión eliminada");
        return "redirect:/reuniones";
    }
}