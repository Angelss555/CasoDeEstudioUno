package com.mettingplanner.CasoDeEstudioUno.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Controller
public class HomeController {
    @GetMapping("/")
    public String index() {
        return "index";
    }
}
