package com.mettingplanner.CasoDeEstudioUno.model;

import java.time.LocalDate;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */
public class Reunion {
    //Creamos los atributos 
    private Long id;
    private String titulo;
    private LocalDate fecha;
    private String hora;
    private Long salaId;
    
    //Creamos el costructor de esta clase
    public Reunion(Long id, String titulo, LocalDate fecha, String hora, Long salaId) {
        this.id = id;
        this.titulo = titulo;
        this.fecha = fecha;
        this.hora = hora;
        this.salaId = salaId;
    }
    
    //Finalmente definimos los Getters & Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) {this.fecha = fecha; }

    public String getHora() { return hora; }
    public void setHora(String hora) { this.hora = hora; }

    public Long getSalaId() { return salaId; }
    public void setSalaId(Long salaId) { this.salaId = salaId;  }
    
}