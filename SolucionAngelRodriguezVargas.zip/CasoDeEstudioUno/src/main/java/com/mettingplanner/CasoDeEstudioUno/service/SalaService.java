package com.mettingplanner.CasoDeEstudioUno.service;

import com.mettingplanner.CasoDeEstudioUno.model.Sala;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

/**
 *
 * @author Angel Felipe Rodríguez Vargas
 */

@Service
public class SalaService {
    //Iniciamos la lista e iniciamos los atributos
    private List<Sala> salas =  new ArrayList<>();
    private Long contadorId = 1L;
    
    //Hacemos una nueva lista para obtener información de sala
    public List<Sala> getAll() {
        return salas;
    }
    
    //Creamos el método para agregar una nueva sala
    public void agregarSala(String nombre, int capacidad) {
        salas.add(new Sala(contadorId++, nombre, capacidad));
    }
    
    //Usamos el optional para crear un filtro
    public Optional<Sala> getById(long id) {
        return salas.stream().filter(s -> s.getId().equals(id)).findFirst();
    }
    
    //Creamos el método para eliminar la Sala
    public void eliminarSala(Long id) {
        salas.removeIf(s -> s.getId().equals(id));
    }
    
    //Para finalizar creamos el método para editar sala
    public void editarSala(Long id, String nombre, int capacidad) {
        getById(id).ifPresent( s -> { 
            s.setNombre(nombre);
            s.setCapacidad(capacidad);       
        });
    }
}