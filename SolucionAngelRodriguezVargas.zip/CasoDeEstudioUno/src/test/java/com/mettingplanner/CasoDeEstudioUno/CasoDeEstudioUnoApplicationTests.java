package com.mettingplanner.CasoDeEstudioUno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasoDeEstudioUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
